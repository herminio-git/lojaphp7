<?php

$smarty = new Template();
$smarty->assign('CONTATO', 'Página de Contatos');
$smarty->display('contato.tpl');




?>